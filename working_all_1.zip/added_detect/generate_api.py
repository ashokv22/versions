import secrets
import base64
import sqlite3

conn = sqlite3.connect('api_db.db', check_same_thread=False)
def generate():
  s1 = secrets.token_urlsafe()
  if conn.execute("SELECT 1 FROM api_keys WHERE api = ?",[s1]).fetchone():
    generate()
  else:
    conn.execute("INSERT INTO api_keys (api,request_count, max_requests)values(?,?,?)",(s1,0, 150000))
    conn.commit()
    return s1
