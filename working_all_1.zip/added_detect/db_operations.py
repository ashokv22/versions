import sqlite3

conn = sqlite3.connect('api_db.db', check_same_thread=False)
# conn.execute("UPDATE api_keys SET max_requests = 150000")
# conn.commit()

# conn.execute('''DELETE FROM api_keys WHERE request_count=0''')

cursor = conn.execute(''' SELECT api,request_count,max_requests from api_keys;''')

for row in cursor:
  print(row)
conn.close()