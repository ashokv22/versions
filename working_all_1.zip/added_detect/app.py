from flask import Flask, request, redirect, render_template, jsonify
import json
# from flask_ngrok import run_with_ngrok
# import main
import detect_language
import speech
import speech_to_text
import voice_output
import interpreter
import generate_api

import sqlite3

conn = sqlite3.connect('api_db.db', check_same_thread=False)

app = Flask(__name__)
# run_with_ngrok(app)
# app.config["SECRET_KEY"] = str(urandom(24));
@app.route('/')
def index():
	return render_template("testing.html")

@app.route('/api')
def api():
    api_generated = generate_api.generate()
    return render_template("api.html", api_key=api_generated)
  
@app.route('/signin')
def signin():
    api_generated = generate_api.generate()
    return render_template("signin.html")

@app.route('/translate', methods = ['POST',"GET"])
def translate():
  form_data=request.get_json(force = True)
  ta_src_lang = form_data['ta_src_lang']
  src_lang = form_data['src_lang']
  if src_lang=="detect":
    candidate_langs = detect_language.detect_lang(ta_src_lang)
    # source_lang = candidate_langs[0]["language"]
    src_lang = candidate_langs
  dest_lang = form_data['dest_lang']
  trans_text=ta_src_lang
  # trans_text = main.translate(src_lang,dest_lang, ta_src_lang)
  response=json.dumps({"src_lang": src_lang,"dest_lang": dest_lang,"ta_src_lang": ta_src_lang,"ta_dest_lang":trans_text})
  return response


@app.route('/text_to_speech', methods = ['POST'])
def text_to_speech():
  form_data = request.get_json(force = True)
  dest_lang = form_data['dest_lang']
  ta_dest_lang = form_data['ta_dest_lang']
  path = speech.play_text(ta_dest_lang,dest_lang)
  response=json.dumps({"dest_lang": dest_lang,"ta_dest_lang":ta_dest_lang,"path":path})
  return response

@app.route('/upload', methods = ['GET', 'POST'])
def upload_file():
	if request.method == 'POST':
		f = request.files['file']
		f.save(('uploads/file1.txt'))
		with open("uploads/file1.txt", "r") as f:
			content = f.readlines()
		return render_template('display_file.html', txt = content)

@app.route('/speechToText', methods = ['GET','POST'])
def speechToText():
  form_data=request.get_json(force = True)
  print(form_data)
  src_lang = form_data['src_lang']
  if src_lang=="detect":
    response=json.dumps({"error": "Choose a specific language to enable voice input"})
    return response
  print(src_lang)
  text_recognized = speech_to_text.speech_to_text(src_lang)
  # trans_text = main.translate(src_lang,dest_lang, ta_src_lang)
  response=json.dumps({"text_recognized": text_recognized})
  return response

@app.route('/manual_speech_src', methods = ['GET','POST'])
def manual_speech_src():
  form_data=request.get_json(force = True)
  # print(form_data)
  src_lang = form_data['src_lang']
  if src_lang=="detect":
    response=json.dumps({"error": "Choose a specific language to enable voice input"})
    return response
  dest_lang = form_data['dest_lang']
  text_recognized = speech_to_text.speech_to_text(src_lang)
  # trans_text = main.translate(src_lang,dest_lang, ta_src_lang)
  # if text_recognized==
  path = speech.play_text(text_recognized,dest_lang)
  response=json.dumps({"text_recognized": text_recognized})
  return response

@app.route('/manual_speech_trg', methods = ['GET','POST'])
def manual_speech_trg():
  form_data=request.get_json(force = True)
  # print(form_data)
  src_lang = form_data['src_lang']
  if src_lang=="detect":
    response=json.dumps({"error": "Choose a specific language to enable voice input"})
    return response
  dest_lang = form_data['dest_lang']
  text_recognized = speech_to_text.speech_to_text(dest_lang)
  # trans_text = main.translate(src_lang,dest_lang, ta_src_lang)
  path = speech.play_text(text_recognized,src_lang)
  response=json.dumps({"text_recognized": text_recognized})
  return response

@app.route('/text_ready', methods = ['POST','GET'])
def text_ready():
  form_data=request.get_json(force = True)
  print(form_data)
  src_lang = form_data['src_lang']
  dest_lang = form_data['dest_lang']
  src_interpreter_lang = interpreter.interpreter_lang_name(src_lang)
  trg_interpreter_lang = interpreter.interpreter_lang_name(dest_lang)
  src_interpreter_greet = interpreter.interpreter_lang_text(src_lang)
  trg_interpreter_greet = interpreter.interpreter_lang_text(dest_lang)

  print(src_interpreter_lang, trg_interpreter_lang, src_interpreter_greet, trg_interpreter_greet)
  response=json.dumps({"src_lang": src_lang,"dest_lang": dest_lang,'src_interpreter_lang':src_interpreter_lang, 'trg_interpreter_lang':trg_interpreter_lang,'src_interpreter_greet':src_interpreter_greet,'trg_interpreter_greet':trg_interpreter_greet})
  return response  

if __name__ == '__main__':
	app.run(debug=True)
