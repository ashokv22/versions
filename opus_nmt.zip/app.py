from flask import Flask, request, redirect, render_template
from os import urandom
import functions
import detect_language

app = Flask(__name__)
app.config["SECRET_KEY"] = str(urandom(24));

@app.route('/')
def index():
	return render_template("index.html")

@app.route('/', methods = ["GET","POST"])
def greeting():
	POST_name = request.form["name"]
	src_lang = detect_language.detect_lang(POST_name)
	trans_text = functions.trans(POST_name)
	return render_template("index.html", name = trans_text)

if __name__ == '__main__':
	app.run(debug = True)
