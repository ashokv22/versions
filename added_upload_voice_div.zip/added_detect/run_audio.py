import speech
mytext=str(input("Enter text: "))
language="en"
speech.play_text(mytext,language)